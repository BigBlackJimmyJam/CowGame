export type DoorOrientation = "Horizontal" | "Vertical";
