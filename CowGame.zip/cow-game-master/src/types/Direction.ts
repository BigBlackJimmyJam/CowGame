export type Direction = "Up" | "Right" | "Down" | "Left";
