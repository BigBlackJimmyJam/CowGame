export * from "./Cow";
export * from "./ICow";
