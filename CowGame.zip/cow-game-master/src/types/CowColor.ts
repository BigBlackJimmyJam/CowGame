export type CowColor = "Brown" | "Grey";
