export interface IEntity {
  img: string;
  linkedHtmlElement: HTMLElement;
}
