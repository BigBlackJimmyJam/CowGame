export type ArrowColor = "Red" | "Blue";
