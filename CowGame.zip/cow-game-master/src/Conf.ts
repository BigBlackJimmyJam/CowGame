export const CONF = {
  Map: {
    width: 20,
    height: 14,
  },
  ArrowsTable: {
    width: 3,
    height: 7,
  },
  loopTime: 250,
};
